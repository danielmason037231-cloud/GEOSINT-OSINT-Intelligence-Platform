import ipaddress
import os
import re
from urllib.parse import urlparse

import httpx
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title="GEOSINT API", version="0.2.0")

origins = [x.strip() for x in os.getenv("ALLOWED_ORIGINS", "http://localhost:3000").split(",") if x.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=False,
    allow_methods=["GET"],
    allow_headers=["*"],
)

@app.get("/health")
async def health():
    return {"status": "ok", "service": "geosint-api"}

def valid_ip(value: str) -> str:
    try:
        addr = ipaddress.ip_address(value)
    except ValueError:
        raise HTTPException(400, "Некорректный IP-адрес")
    if addr.is_private or addr.is_loopback or addr.is_link_local or addr.is_reserved:
        raise HTTPException(400, "Для этого MVP доступны только публичные IP-адреса")
    return str(addr)

@app.get("/api/ip/{value}")
async def ip_lookup(value: str):
    ip = valid_ip(value)
    # ip-api returns approximate network-level data, not a person's precise location.
    async with httpx.AsyncClient(timeout=8.0, follow_redirects=False) as client:
        try:
            response = await client.get(
                f"http://ip-api.com/json/{ip}",
                params={"fields": "status,message,query,country,countryCode,regionName,city,zip,lat,lon,isp,org,as,timezone"},
            )
            response.raise_for_status()
            data = response.json()
        except (httpx.HTTPError, ValueError):
            raise HTTPException(502, "Внешний источник временно недоступен")
    if data.get("status") != "success":
        raise HTTPException(404, data.get("message", "Информация не найдена"))
    return {
        "ip": data.get("query"), "country": data.get("country"),
        "country_code": data.get("countryCode"), "region": data.get("regionName"),
        "city": data.get("city"), "postal_code": data.get("zip"),
        "latitude": data.get("lat"), "longitude": data.get("lon"),
        "isp": data.get("isp"), "organization": data.get("org"),
        "asn": data.get("as"), "timezone": data.get("timezone"),
        "notice": "Геолокация IP приблизительная и не определяет точный адрес или личность человека."
    }

def valid_domain(value: str) -> str:
    value = value.strip().lower().rstrip(".")
    if "://" in value:
        value = urlparse(value).hostname or ""
    if not value or len(value) > 253 or not re.fullmatch(r"(?=.{1,253}$)([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}", value):
        raise HTTPException(400, "Некорректное доменное имя")
    return value

@app.get("/api/domain/{value}")
async def domain_lookup(value: str):
    domain = valid_domain(value)
    async with httpx.AsyncClient(timeout=10.0, follow_redirects=False) as client:
        try:
            response = await client.get(f"https://rdap.org/domain/{domain}", headers={"Accept": "application/rdap+json"})
            if response.status_code == 404:
                raise HTTPException(404, "Домен не найден в RDAP")
            response.raise_for_status()
            data = response.json()
        except HTTPException:
            raise
        except (httpx.HTTPError, ValueError):
            raise HTTPException(502, "RDAP-источник временно недоступен")
    events = data.get("events", [])
    nameservers = [x.get("ldhName") for x in data.get("nameservers", []) if x.get("ldhName")]
    return {
        "domain": data.get("ldhName", domain),
        "handle": data.get("handle"),
        "status": data.get("status", []),
        "nameservers": nameservers,
        "events": [{"action": e.get("eventAction"), "date": e.get("eventDate")} for e in events],
        "entities": [{"handle": e.get("handle"), "roles": e.get("roles", [])} for e in data.get("entities", [])],
        "notice": "RDAP показывает только опубликованные регистрационные данные; часть полей может быть скрыта."
    }
