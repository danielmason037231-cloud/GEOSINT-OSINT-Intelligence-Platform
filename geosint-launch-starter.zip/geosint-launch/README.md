# GEOSINT — launch starter

This is a deployable starter, not a live hosted website. It contains:
- Next.js frontend (Vercel)
- FastAPI backend (Render)
- IP lookup (approximate network/geolocation metadata; never a person's exact location)
- Domain lookup via RDAP
- Basic input validation and CORS configuration

## 1. Deploy the backend (Render)
1. Push this folder to a GitHub repository.
2. In Render, create a **Blueprint** from that repository. Render reads `render.yaml`.
3. After deployment, copy the backend URL, e.g. `https://geosint-api.onrender.com`.

## 2. Deploy the frontend (Vercel)
1. Import the same GitHub repository into Vercel.
2. Set **Root Directory** to `frontend`.
3. Add environment variable `NEXT_PUBLIC_API_URL` with the Render backend URL.
4. Deploy. Vercel provides a free `*.vercel.app` address.

## 3. Local run
Backend:
```bash
cd backend
python -m venv .venv
# Windows PowerShell: .\.venv\Scripts\Activate.ps1
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```
Frontend (new terminal):
```bash
cd frontend
npm install
# Windows PowerShell: $env:NEXT_PUBLIC_API_URL="http://localhost:8000"
npm run dev
```
Open http://localhost:3000

## Before opening to the public
This is an MVP scaffold. Add authentication, rate limiting, abuse reporting, privacy policy,
terms, logging controls, monitoring, and subscription/payment integration before public launch.
Do not use it to identify, track, harass, or access private accounts. IP location is approximate.
