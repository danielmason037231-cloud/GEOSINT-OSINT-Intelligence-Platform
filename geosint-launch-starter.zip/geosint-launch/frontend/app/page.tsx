'use client';
import { useState } from 'react';

const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

function Tool({ title, description, placeholder, endpoint }: {title:string;description:string;placeholder:string;endpoint:string}) {
  const [value,setValue] = useState('');
  const [result,setResult] = useState('');
  const [busy,setBusy] = useState(false);
  async function run() {
    if (!value.trim()) return;
    setBusy(true); setResult('');
    try {
      const response = await fetch(`${API}${endpoint}/${encodeURIComponent(value.trim())}`);
      const data = await response.json();
      setResult(JSON.stringify(data,null,2));
    } catch {
      setResult('Не удалось подключиться к API. Проверьте NEXT_PUBLIC_API_URL и доступность backend.');
    } finally { setBusy(false); }
  }
  return <section className="panel">
    <h2>{title}</h2><div className="muted">{description}</div>
    <div className="form"><input value={value} onChange={e=>setValue(e.target.value)} placeholder={placeholder} onKeyDown={e=>e.key==='Enter'&&run()} /><button onClick={run} disabled={busy}>{busy?'Поиск…':'Анализировать'}</button></div>
    {result && <pre className="result">{result}</pre>}
  </section>;
}

export default function Home() {
  return <main className="shell">
    <header className="top"><div className="brand">GEOSINT<span style={{color:'#75e0c1'}}>.</span></div><div className="tag">OPEN SOURCE INTELLIGENCE</div></header>
    <section className="hero"><div className="tag">OSINT WORKSPACE / MVP</div><h1>Исследуй открытые данные.</h1><p>Набор инструментов для анализа публичной информации. Начните с IP-адреса или домена. Результаты зависят от доступности внешних источников.</p></section>
    <div className="grid">
      <Tool title="IP Analyzer" description="Публичные сетевые сведения и приблизительная география IP." placeholder="Например, 1.1.1.1" endpoint="/api/ip" />
      <Tool title="Domain Analyzer" description="Регистрационные сведения RDAP, статусы и nameservers домена." placeholder="Например, example.com" endpoint="/api/domain" />
    </div>
    <footer className="foot">GEOSINT MVP · Используйте только законные источники и соблюдайте приватность. IP-геолокация приблизительна и не устанавливает точное местонахождение человека. Сейчас доступны два инструмента; регистрация, подписки и остальные модули ещё не подключены.</footer>
  </main>;
}
