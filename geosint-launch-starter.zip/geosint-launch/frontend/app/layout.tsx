import './globals.css';
import type { Metadata } from 'next';
export const metadata: Metadata = { title: 'GEOSINT — Open Source Intelligence', description: 'Инструменты анализа открытых данных' };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="ru"><body>{children}</body></html>;
}
